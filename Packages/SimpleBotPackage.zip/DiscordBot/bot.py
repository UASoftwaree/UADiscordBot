###############################################
#      Script Below is for Your Desktop
###############################################

import discord
from discord.ext import commands


bot = commands.Bot(command_prefix='>')
bot.remove_command('help')
token = "Token Here"

@bot.command()
async def ping(ctx):
  await ctx.send('pong')

@bot.command()
async def hello(ctx):
  await ctx.send("Hello There")

bot.run(token)

############################################################
#          Repl.it
############################################################

#If youre using Repli.it

import discord
from discord.ext import commands
import os
from keep_alive import keep_alive

bot = commands.Bot(command_prefix=">")
bot.remove_command('help')
#Place your Bot Token in Secrets
token = os.environ['Token']

@bot.command()
async def ping(ctx):
  await ctx.send("Pong")

@bot.command()
async def hello(ctx):
  await ctx.send("Hello There")

bot.run(token)
